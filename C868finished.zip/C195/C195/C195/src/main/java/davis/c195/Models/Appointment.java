package davis.c195.Models;


import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Model for Appointment
 * @author Brandon Davis
 */
public class Appointment {
    private final SimpleIntegerProperty AppointmentID = new SimpleIntegerProperty();
    private final SimpleIntegerProperty CustomerID = new SimpleIntegerProperty();
    private final SimpleStringProperty Start = new SimpleStringProperty();
    private final SimpleStringProperty End = new SimpleStringProperty();
    private final SimpleStringProperty Title = new SimpleStringProperty();
    private final SimpleStringProperty Description = new SimpleStringProperty();
    private final SimpleStringProperty Location = new SimpleStringProperty();
    private final SimpleStringProperty Contact = new SimpleStringProperty();
    private final SimpleStringProperty Type = new SimpleStringProperty();
    private final SimpleIntegerProperty UserID = new SimpleIntegerProperty();


    /**
     * Constructor for Appointment Information
     * @param AppointmentID
     * @param CustomerID
     * @param Start
     * @param End
     * @param Title
     * @param Description
     * @param Location
     * @param Contact
     * @param Type
     * @param UserID
     */
    public Appointment(int AppointmentID, int CustomerID, String Start, String End, String Title, String Description, String Location, String Contact, String Type, int UserID) {
        setAppointmentID(AppointmentID);
        setCustomerID(CustomerID);
        setStart(Start);
        setEnd(End);
        setTitle(Title);
        setDescription(Description);
        setLocation(Location);
        setContact(Contact);
        setType(Type);
        setUserID(UserID);

    }

    /**
     * Getter for Appointment ID
     * @return AppointmentID
     */
    public int getAppointmentID() {
        return AppointmentID.get();
    }

    /**
     * Getter for Customer ID
     * @return CustomerID
     */
    public int getCustomerID() {
        return CustomerID.get();
    }

    /**
     * Getter for End
     * @return End
     */
    public String getEnd() {
        return End.get();
    }

    /**
     * Getter for Start
     * @return Start
     */
    public String getStart() {
        return Start.get();
    }

    /**
     * Getter Title
     * @return Title
     */
    public String getTitle() {
        return Title.get();
    }

    /**
     * Getter for Description
     * @return Description
     */
    public String getDescription() {
        return Description.get();
    }

    /**
     * Getter for Location
     * @return Location
     */
    public String getLocation() {
        return Location.get();
    }

    /**
     * Getter for Contact
     * @return Contact
     */
    public String getContact() {
        return Contact.get();
    }

    /**
     * Getter for Type
     * @return Type
     */
    public String getType() {
        return Type.get();
    }

    /**
     *Getter for UserID
     * @return UserID
     */
    public int getUserID() {
        return UserID.get();
    }

    /**
     * Setter for Appointment ID
     * @param AppointmentID
     */
    public void setAppointmentID(int AppointmentID) {
        this.AppointmentID.set(AppointmentID);
    }

    /**
     * Setter for Customer ID
     * @param CustomerID
     */
    public void setCustomerID(int CustomerID) {
        this.CustomerID.set(CustomerID);
    }

    /**
     * Setter for End
     * @param End
     */
    public void setEnd(String End) {
        this.End.set(End);
    }

    /**
     * Setter for Start
     * @param Start
     */
    public void setStart(String Start) {
        this.Start.set(Start);
    }

    /**
     * Setter for Title
     * @param Title
     */
    public void setTitle(String Title) {
        this.Title.set(Title);
    }

    /**
     * Setter for Description
     * @param Description
     */
    public void setDescription(String Description) {
        this.Description.set(Description);
    }

    /**
     * Setter for Location
     * @param Location
     */
    public void setLocation(String Location) {
        this.Location.set(Location);
    }

    /**
     * Setter for Contact
     * @param Contact
     */
    public void setContact(String Contact) {
        this.Contact.set(Contact);
    }

    /**
     * Setter for Type
     * @param Type
     */
    public void setType(String Type) {this.Type.set(Type);}

    /**
     * Setter for User ID
     * @param UserID
     */
    public void setUserID(int UserID) {this.UserID.set(UserID);}

    /**
     * Getter property for End
     * @return End
     */
    public StringProperty getEndProperty() {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime ldt = LocalDateTime.parse(this.End.getValue(), df);
        ZonedDateTime zdt = ldt.atZone(ZoneId.of("UTC"));
        ZoneId zid = ZoneId.systemDefault();
        ZonedDateTime utcDate = zdt.withZoneSameInstant(zid);
        StringProperty date = new SimpleStringProperty(utcDate.toLocalDateTime().toString());
        return date;
    }

    /**
     * Getter property for Start
     * @return Start
     */
    public StringProperty getStartProperty() {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime ldt = LocalDateTime.parse(this.Start.getValue(), df);
        ZonedDateTime zdt = ldt.atZone(ZoneId.of("UTC"));
        ZoneId zid = ZoneId.systemDefault();
        ZonedDateTime utcDate = zdt.withZoneSameInstant(zid);
        StringProperty date = new SimpleStringProperty(utcDate.toLocalDateTime().toString());
        return date;
    }

    /**
     * Getter property for Title
     * @return Title
     */
    public StringProperty getTitleProperty() {
        return this.Title;
    }

    /**
     * Getter property for Description
     * @return Description
     */
    public StringProperty getDescriptionProperty() {
        return this.Description;
    }

    /**
     * Getter property for Location
     * @return Location
     */
    public StringProperty getLocationProperty() {
        return this.Location;
    }

    /**
     * Getter property for Contact
     * @return Contact
     */
    public StringProperty getContactProperty() {
        return this.Contact;
    }

    /**
     * Getter property for Appointment ID
     * @return AppointmentID
     */
    public IntegerProperty getAppointmentIDProperty() {return this.AppointmentID;}

    /**
     * Getter property for Type
     * @return Type
     */
    public StringProperty getTypeProperty() { return this.Type; }

    /**
     * Getter property for UserID
     * @return UserID
     */
    public IntegerProperty getUserIDProperty() {return this.UserID;}

    /**
     * Getter property for Customer ID
     * @return CustomerID
     */
    public IntegerProperty getCustomerIDProperty() {return this.CustomerID;}


}

