package davis.c195.Controllers;

import davis.c195.Models.CustomerDB;
import davis.c195.helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for Customer Updatescreen
 * @author Brandon Davis
 */

public class Customerupdate implements Initializable {

    @FXML
    private TextField AddressText;

    @FXML
    private ComboBox<String> CityBox;

    @FXML
    private ComboBox<String> CountryBox;

    @FXML
    private TextField NameText;

    @FXML
    private TextField PhoneText;

    @FXML
    private TextField PostalText;

    @FXML
    private TextField CustomerIDText;
    @FXML
    private Text upcustLabel;
    @FXML
    private Text custName;
    @FXML
    private Text custAddress;
    @FXML
    private Text custPhone;
    @FXML
    private Text custPost;
    @FXML
    private Text custCountry;
    @FXML
    private Text custCity;
    @FXML
    private Text custID;
    @FXML
    private Button Savebutton;
    @FXML
    private Button Cancelbutton;

    /**
     * Method for setting all the customer information in the form
     * @param CustomerID
     * @param CustomerName
     * @param Address
     * @param Phone
     * @param PostalCode
     * @param CityID
     */
    public void setCustomerInformation(int CustomerID, String CustomerName, String Address, String Phone, String PostalCode, String CityID) {
        CustomerIDText.setText(Integer.toString(CustomerID));
        NameText.setText(CustomerName);
        PhoneText.setText(Phone);
        AddressText.setText(Address);
        CityBox.setValue(CustomerDB.getDivisionName(CityID));
        CountryBox.setValue(CustomerDB.getCountryByDivisionName(CityBox.getValue()));
        PostalText.setText(PostalCode);
    }

    /**
     * Method for listing all the available city options
     */
    private ObservableList<String> UKCities = FXCollections.observableArrayList("Northern Ireland", "Scotland", "Wales", "England");
    private ObservableList<String> CanadaCities = FXCollections.observableArrayList("Newfoundland and Labrador", "Yukon", "Nunavut", "Saskatchewan", "Ontario",
            "Quebec", "Prince Edward Island", "Nova Scotia", "New Brunswick", "Manitoba", "British Columbia", "Alberta", "Northwest Territories");
    private ObservableList<String> USCities = FXCollections.observableArrayList("Alabama", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia",
            "Florida", "Georgia", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi",
            "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania",
            "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming", "Hawaii", "Alaska");

    String[] CountryOptions = {"United States", "Canada", "United Kingdom"};

    /**
     * Handles the cancel button action, redirects the user back to the customer main screen
     * @param event
     * @throws IOException
     */
    @FXML
    void cancelButtonAction(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Customermain.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method to set the country options in the combo box
     * @param event
     */
    @FXML
    void setCountry(ActionEvent event) {
        String selectedCountry = CountryBox.getValue();
        if (selectedCountry != null) {
            updateCityOptions(selectedCountry);
        }
    }

    /**
     * Handles the save button action, this saves the updated customer information to the database and uses a logic check to make sure all areas are filled in before you can submit it
     * @param event
     * @return
     * @throws IOException
     */
    @FXML
    public boolean saveButtonAction(ActionEvent event) throws IOException{
        String customerID = CustomerIDText.getText();
        String customerName = NameText.getText();
        String address = AddressText.getText();
        String phone = PhoneText.getText();
        String cityName = CityBox.getValue();
        String postalCode = PostalText.getText();

        if (customerID.isEmpty() || customerName.isEmpty() || address.isEmpty() || phone.isEmpty() || cityName == null || postalCode.isEmpty()) {
            return false;
        } else {

                CustomerDB.updateCustomer(Integer.parseInt(customerID), customerName, address, phone, postalCode, cityName);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/Customermain.fxml"));
                Parent parent = loader.load();
                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
                return true;
        }

    }

    /**
     * Method of displaying the appropriate cities based on the selected country
     * @param selectedCountry
     */
    private void updateCityOptions(String selectedCountry) {
        if (selectedCountry.equals("United States")) {
            CityBox.setItems(USCities);
        } else if (selectedCountry.equals("Canada")) {
            CityBox.setItems(CanadaCities);
        } else if (selectedCountry.equals("United Kingdom")) {
            CityBox.setItems(UKCities);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        JDBC.openConnection();
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        upcustLabel.setText(resourceBundle.getString("uppcusttable"));
        custName.setText(resourceBundle.getString("namelabel"));
        custAddress.setText(resourceBundle.getString("addresslabel"));
        custPhone.setText(resourceBundle.getString("phonelabel"));
        custPost.setText(resourceBundle.getString("postalcode"));
        custCountry.setText(resourceBundle.getString("countrylabel"));
        custCity.setText(resourceBundle.getString("citylabel"));
        Savebutton.setText(resourceBundle.getString("savebutton"));
        Cancelbutton.setText(resourceBundle.getString("cancelButton"));
        custID.setText(resourceBundle.getString("customerIDlabel"));
        CountryBox.setItems(FXCollections.observableArrayList(CountryOptions));
        CityBox.setItems(FXCollections.observableArrayList());
    }
}


