package davis.c195.Models;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;

import davis.c195.helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 * Model for Appointment Database functions
 * @author Brandon Davis
 */
public class AppointmentDB {

    /**
     * Creates way to gather all appointments and filters between the monthly and weekly
     * @param filter
     * @return
     * @throws SQLException
     */
    public static ObservableList<Appointment> getAllAppointments(String filter) throws SQLException {
        ObservableList<Appointment> appointmentsObservableList = FXCollections.observableArrayList();
        Appointment appointment;
        try {
            String query;
            if (filter.equalsIgnoreCase("week")) {
                LocalDateTime start = LocalDateTime.now();
                LocalDateTime end = start.plusWeeks(1);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String startDateTime = start.format(formatter);
                String endDateTime = end.format(formatter);
                query = "SELECT * FROM appointments WHERE Start >= '" + startDateTime + "' AND End <= '" + endDateTime + "'";
            } else if (filter.equalsIgnoreCase("month")) {
                LocalDateTime start = LocalDateTime.now();
                LocalDateTime end = start.plusMonths(1);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String startDateTime = start.format(formatter);
                String endDateTime = end.format(formatter);
                query = "SELECT * FROM appointments WHERE Start >= '" + startDateTime + "' AND End <= '" + endDateTime + "'";
            } else {
                query = "SELECT * FROM appointments";
            }

            Statement statement = JDBC.getConnection().createStatement();
            ResultSet results = statement.executeQuery(query);
            while (results.next()) {
                appointment = new Appointment(results.getInt("Appointment_ID"), results.getInt("Customer_ID"), results.getString("Start"),
                        results.getString("End"), results.getString("Title"), results.getString("Description"),
                        results.getString("Location"), results.getString("Contact_ID"), results.getString("Type"), results.getInt("User_ID"));
                appointmentsObservableList.add(appointment);
            }
            statement.close();
            return appointmentsObservableList;

        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return null;
        }
    }


    /**
     * Method used to save appointments to the database
     * @param customerID
     * @param title
     * @param description
     * @param type
     * @param contactID
     * @param location
     * @param date
     * @param time
     * @param userID
     * @return
     */
    public static boolean saveAppointment(int customerID, String title, String description, String type, int contactID, String location, LocalDate date, LocalTime time, int userID) {
        String tsStart = createTimeStamp(date.toString(), time.toString(), location, true);
        String tsEnd = createTimeStamp(date.toString(), time.toString(), location, false);

        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "INSERT INTO appointments SET Customer_ID='" + customerID  + "', Title='" + title + "', Description='" +
                    description + "', Contact_ID='" + contactID + "', Location='" + location +  "', Type='" + type +  "', Start='" + tsStart + "', End='" +
                    tsEnd+ "', User_ID='" + userID + "'";
            int update = statement.executeUpdate(query);
            if (update == 1) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    /**
     * Method used to update appointment info from the appointment tableview to then be saved in the database
     * @param appointmentID
     * @param title
     * @param description
     * @param type
     * @param contactID
     * @param location
     * @param date
     * @param time
     * @param userID
     * @return
     */
    public static boolean updateAppointment(int appointmentID, String title, String description, String type, int contactID, String location, String date, String time, int userID) {
        String tsStart = createTimeStamp(date, time, location, true);
        String tsEnd = createTimeStamp(date, time, location, false);

        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "UPDATE appointments SET Title='" + title + "', Description='" + description + "', Contact_ID='" +
                    contactID + "', Location='" + location + "', Type='" + type +"', Start='" + tsStart + "', End='" + tsEnd + "', User_ID='"+ userID + "' WHERE " +
                    "Appointment_ID='" + appointmentID + "'";
            int update = statement.executeUpdate(query);
            if (update == 1) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }

        return false;
    }

    /**
     * Method used to check for any overlapping appointments
     * @param AppointmentID
     * @param Location
     * @param Date
     * @param Time
     * @return
     */
    public static boolean overlappingAppointment(int AppointmentID, String Location, LocalDate Date, LocalTime Time) {
        String Start = createTimeStamp(Date.toString(), Time.toString(), Location, true);
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT * FROM appointments WHERE Start = '" + Start + "' AND Location = '" + Location + "'";
            ResultSet results = statement.executeQuery(query);
            if (results.next()) {
                if (results.getInt("Appointment_ID") == AppointmentID) {
                    statement.close();
                    return false;
                }
                statement.close();
                return true;
            } else {
                statement.close();
                return false;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return true;
        }
    }

    public static boolean Appointmentconflict(int AppointmentID, int contactID, String Location, LocalDate Date, LocalTime Time) {
        String Start = createTimeStamp(Date.toString(), Time.toString(), Location, true);
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT * FROM appointments WHERE Start = '" + Start + "' AND Contact_ID = '" + contactID + "'";
            ResultSet results = statement.executeQuery(query);
            if (results.next()) {
                if (results.getInt("Appointment_ID") == AppointmentID) {
                    statement.close();
                    return false;
                }
                statement.close();
                return true;
            } else {
                statement.close();
                return false;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return true;
        }
    }



    /**
     * Method used to delete appointments from the database
     * @param AppointmentID
     * @return
     */
    public static boolean deleteAppointment(int AppointmentID) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "DELETE FROM appointments WHERE Appointment_ID = " + AppointmentID;
            int update = statement.executeUpdate(query);
            if(update == 1) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    /**
     * Method to create timestamps for when new appointments are saved to the database of when the current information has been updated
     * @param Date
     * @param Time
     * @param Location
     * @param startMode
     * @return
     */
    public static String createTimeStamp(String Date, String Time, String Location, boolean startMode) {
        String h = Time.split(":")[0];
        int rawH = Integer.parseInt(h);
        if(rawH < 8) {
            rawH += 12;
        }
        if(!startMode) {
            rawH += 1;
        }
        String rawD = String.format("%s %02d:%s", Date, rawH, "00");
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime ldt = LocalDateTime.parse(rawD, df);
        ZoneId zid;
        if(Location.equals("New Jersey")) {
            zid = ZoneId.of("America/New_Jersey");
        } else if(Location.equals("Scotland")) {
            zid = ZoneId.of("Europe/London");
        } else {
            zid = ZoneId.of("America/Yellowknife");
        }
        ZonedDateTime zdt = ldt.atZone(zid);
        ZonedDateTime utcDate = zdt.withZoneSameInstant(ZoneId.of("UTC"));
        ldt = utcDate.toLocalDateTime();
        Timestamp ts = Timestamp.valueOf(ldt);
        return ts.toString();
    }

}