package davis.c195.Controllers;

import davis.c195.Models.AppointmentDB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;



/**
 * Controller for Appointment Modify Screen
 * @author Brandon Davis
 */

public class Appointmentmodify implements Initializable {

    @FXML
    private ComboBox AppointmentType;

    @FXML
    private TextField AppointmentID;

    @FXML
    private ComboBox ContactBox;

    @FXML
    private TextField CustomerID;

    @FXML
    private TextField Description;

    @FXML
    private ComboBox EndTime;

    @FXML
    private TextField Location;

    @FXML
    private ComboBox StartTime;

    @FXML
    private TextField Title;


    @FXML
    private TextField UserID;

    @FXML
    private DatePicker StartDate;

    @FXML
    private DatePicker EndDate;
    @FXML
    private Text modAppLabel;
    @FXML
    private Text appID;
    @FXML
    private Text custID;
    @FXML
    private Text userID;
    @FXML
    private Text appTitle;
    @FXML
    private Text appDesc;
    @FXML
    private Text appLocation;
    @FXML
    private Text appContact;
    @FXML
    private Text appStart;
    @FXML
    private Text appEnd;
    @FXML
    private Text appType;
    @FXML
    private Text appStartTime;
    @FXML
    private Text appEndTime;
    @FXML
    private Button UpdateButton;
    @FXML
    private Button CancelButton;
    private String errorTitle;
    private String successTitle;
    private String wrongTime;
    private String wrongTimeMessage;
    private String wrongDate;
    private String wrongDateMessage;
    private String overlappingApp;
    private String overlappingMessage;
    private String updateSuccess;
    private String updateSuccessMessage;
    private String updatefail;
    private String updatefailmessage;
    private String appconflict;


    private int appointmentID;

    private final ObservableList<String> times = FXCollections.observableArrayList("8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM",
            "1:30 PM", "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM");

    private final ObservableList<String> type = FXCollections.observableArrayList("De-Briefing", "Planning Session", "After Action Review", "Consultation");

    private final ObservableList<String> contact = FXCollections.observableArrayList("Anika Costa", "Daniel Garcia", "Li Lee");

    public void setAppointmentInformation(int appointmentID, int customerID, int userID, String title, String description, String Type, String Contact, String location, LocalDate startDate, LocalTime startTime,LocalDate endDate, LocalTime endTime) {

        /**
         *Sets the appointment information
         */

        this.appointmentID=appointmentID;
        AppointmentID.setText(Integer.toString(appointmentID));
        CustomerID.setText(Integer.toString(customerID));
        UserID.setText(Integer.toString(userID));
        Title.setText(title);
        Description.setText(description);
        Location.setText(location);

        /**
         * Sets contact combo box
         */

        ContactBox.setValue(Contact);

        /**
         * Sets start time combo box
         */

        StartTime.setValue(startTime);

        /**
         * Sets end time combo box
         */

        EndTime.setValue(endTime);

        /**
         * Sets appointment type combo box
         */

        AppointmentType.setValue(Type);

        /**
         * Sets appointment start date
         */

        StartDate.setValue(startDate);

        /**
         * Sets appointment end date
         */

        EndDate.setValue(endDate);
    }

    /**
     * Handles the cancel button action, this redirects the user back to the appointment main screen
     * @param event
     * @throws IOException
     */

    @FXML
    void cancelButton(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Appointmentmain.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    /**
     * Handles the update button action, this takes all the information from the user and begins to check for empty areas, if the updated appointment is outside operational hours, as well as overlapping appointments
     * @param event
     * @return
     */

    @FXML
    public boolean updateButton(ActionEvent event) {
        int userID = Integer.parseInt(UserID.getText());
        int appointmentID = Integer.parseInt(AppointmentID.getText());
        String description = Description.getText();
        String location = Location.getText();
        String contact = (String) ContactBox.getValue();
        String start = (String) StartTime.getValue();
        String end = (String) EndTime.getValue();
        String title = Title.getText();
        String type = (String) AppointmentType.getValue();
        LocalDate startDate = StartDate.getValue();
        LocalDate endDate = EndDate.getValue();

        if (description.isEmpty() || location.isEmpty() || contact == null || start == null || end == null ||
                title.isEmpty() || type == null || startDate == null || endDate == null) {
            return false;
        } else {
            LocalTime startTime = LocalTime.parse(start, DateTimeFormatter.ofPattern("h:mm a"));
            LocalTime endTime = LocalTime.parse(end, DateTimeFormatter.ofPattern("h:mm a"));

            /**
             * Checks if the appointment falls within operating hours (8 am - 10 pm EST)
             */

            LocalTime operatingHoursStart = LocalTime.of(8, 0);
            LocalTime operatingHoursEnd = LocalTime.of(22, 0);
            ZoneId estZone = ZoneId.of("America/New_York");
            ZonedDateTime startDateTimeEST = ZonedDateTime.of(startDate, startTime, estZone);
            ZonedDateTime endDateTimeEST = ZonedDateTime.of(endDate, endTime, estZone);

            if (startDateTimeEST.toLocalTime().isBefore(operatingHoursStart) ||
                    endDateTimeEST.toLocalTime().isAfter(operatingHoursEnd)) {
                showErrorAlert(wrongTime, wrongTimeMessage);
                return false;
            }

            /**
             * Checks if the appointment falls on a weekend (Saturday or Sunday)
             */

            if (startDate.getDayOfWeek() == DayOfWeek.SATURDAY || startDate.getDayOfWeek() == DayOfWeek.SUNDAY ||
                    endDate.getDayOfWeek() == DayOfWeek.SATURDAY || endDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
                showErrorAlert(wrongDate, wrongDateMessage);
                return false;
            }

            /**
             * Checks if the appointment overlaps with existing appointments
             */

            if (overlappingAppointment(appointmentID, location, startDate, startTime)) {
                showErrorAlert(overlappingApp, overlappingMessage);
                return false;
            }

            int contactID = getContactID(contact);
            if (AppointmentDB.Appointmentconflict(0, contactID , location,startDate,startTime)) {
                showErrorAlert(overlappingApp,appconflict);
                return false;
            }
            else
            {

                /**
                 * Converts LocalDate and LocalTime to String format for the updateAppointment method
                 */

                String date = startDate.toString();
                String time = startTime.format(DateTimeFormatter.ofPattern("HH:mm"));
                boolean isUpdated = AppointmentDB.updateAppointment(appointmentID, title, description, type, contactID, location, date, time, userID);

                if (isUpdated) {
                    showSuccessAlert(updateSuccess, updateSuccessMessage);
                    return true;
                } else {
                    showErrorAlert(updatefail, updatefailmessage);
                    return false;
                }

            }

        }

    }

    /**
     * Method to get the Contact ID from the Contact Name
     * @param contactName
     * @return
     */

    private int getContactID(String contactName) {
        switch (contactName) {
            case "Anika Costa":
                return 1;
            case "Daniel Garcia":
                return 2;
            case "Li Lee":
                return 3;
            default:
                return 0;
        }
    }

    /**
     * Handles error message thrown
     * @param title
     * @param message
     */

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(errorTitle);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Handles the success message thrown
     * @param title
     * @param message
     */

    private void showSuccessAlert(String title, String message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(successTitle);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Handles the method for overlappingAppointments
     * @param appointmentID
     * @param location
     * @param startDate
     * @param startTime
     * @return
     */
    private boolean overlappingAppointment(int appointmentID, String location, LocalDate startDate, LocalTime startTime) {
        return AppointmentDB.overlappingAppointment(appointmentID, location, startDate, startTime);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        appID.setText(resourceBundle.getString("appointmentID"));
        custID.setText(resourceBundle.getString("customerIDlabel"));
        userID.setText(resourceBundle.getString("userID"));
        appTitle.setText(resourceBundle.getString("titlelabel"));
        appDesc.setText(resourceBundle.getString("descriptionlabel"));
        appLocation.setText(resourceBundle.getString("locationtag"));
        appContact.setText(resourceBundle.getString("contactlabel"));
        appStart.setText(resourceBundle.getString("startdate"));
        appEnd.setText(resourceBundle.getString("enddate"));
        appType.setText(resourceBundle.getString("apptype"));
        appStartTime.setText(resourceBundle.getString("starttime"));
        appEndTime.setText(resourceBundle.getString("endtime"));
        UpdateButton.setText(resourceBundle.getString("updatebutton"));
        CancelButton.setText(resourceBundle.getString("cancelButton"));
        modAppLabel.setText(resourceBundle.getString("modapplabel"));
        errorTitle = resourceBundle.getString("errortitle");
        successTitle = resourceBundle.getString("successtitle");
        wrongTime = resourceBundle.getString("wrongtime");
        wrongTimeMessage = resourceBundle.getString("wrongtimemessage");
        wrongDate = resourceBundle.getString("wrongdate");
        wrongDateMessage = resourceBundle.getString("wrongdatemessage");
        overlappingApp = resourceBundle.getString("overlappingApp");
        overlappingMessage = resourceBundle.getString("overlappingMessage");
        updateSuccess = resourceBundle.getString("updateSuccess");
        updateSuccessMessage = resourceBundle.getString("updateSuccessMessage");
        updatefail = resourceBundle.getString("updatefail");
        updatefailmessage = resourceBundle.getString("updatefailmessage");
        appconflict = resourceBundle.getString("appconflict");


        ContactBox.setItems(contact);
        StartTime.setItems(times);
        EndTime.setItems(times);
        AppointmentType.setItems(type);
    }
}

