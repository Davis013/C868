package davis.c195.Controllers;


import davis.c195.Models.AppointmentDB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for Appointment Add
 * @author Brandon Davis
 */

public class Appointmentadd implements Initializable {

    @FXML
    private Button AddButton;
    @FXML
    private Button CancelButton;

    @FXML
    private ComboBox<String> AppointmentType;

    @FXML
    private ComboBox<String> ContactBox;

    @FXML
    private TextField CustomerID;

    @FXML
    private TextField Description;

    @FXML
    private ComboBox<String> EndTime;

    @FXML
    private TextField Location;

    @FXML
    private ComboBox<String> StartTime;

    @FXML
    private TextField Title;

    @FXML
    private TextField UserID;

    @FXML
    private DatePicker StartDate;

    @FXML
    private DatePicker EndDate;
    @FXML
    private Text addAppLabel;
    @FXML
    private Text appID;
    @FXML
    private Text custID;
    @FXML
    private Text userID;
    @FXML
    private Text appDesc;
    @FXML
    private Text appTitle;
    @FXML
    private Text appLocation;
    @FXML
    private Text appContact;
    @FXML
    private Text appStart;
    @FXML
    private Text appEnd;
    @FXML
    private Text appType;
    @FXML
    private Text appStartTime;
    @FXML
    private Text appEndTime;

    private String errorTitle;
    private String fillinfo;
    private String wrongTime;
    private String wrongDateMessage;
    private String badapptime;
    private String failsave;


    private final ObservableList<String> times = FXCollections.observableArrayList(
            "8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM",
            "1:30 PM", "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM");

    private final ObservableList<String> type = FXCollections.observableArrayList(
            "De-Briefing", "Planning Session", "After Action Review", "Consultation"
    );

    private final ObservableList<String> contact = FXCollections.observableArrayList(
            "Anika Costa", "Daniel Garcia", "Li Lee"
    );


    /**
     * Handles the add button action, Redirects the user to the appointment add screen where the user can add an appointment to the database
     * @param event
     */

    @FXML
    void addButton(ActionEvent event) {

        /**
         * Gets the values from the input fields
         */

        // Get the values from the input fields
        String title = Title.getText();
        String description = Description.getText();
        String location = Location.getText();
        String contact = ContactBox.getValue();
        String type = AppointmentType.getValue();
        int customerID = Integer.parseInt(CustomerID.getText());
        int userID = Integer.parseInt(UserID.getText());
        LocalDate startDate = StartDate.getValue();
        LocalDate endDate = EndDate.getValue();
        LocalTime startTime = LocalTime.parse(StartTime.getValue(), DateTimeFormatter.ofPattern("h:mm a"));
        LocalTime endTime = LocalTime.parse(EndTime.getValue(), DateTimeFormatter.ofPattern("h:mm a"));

        /**
         * Validates the input fields
         */

        if (title.isEmpty() || description.isEmpty() || location.isEmpty() ||
                contact == null || type == null || customerID == 0 || userID == 0 ||
                startDate == null || endDate == null || startTime == null || endTime == null) {
            showErrorMessage(fillinfo);
            return;
        }

        /**
         * Checks if the appointment falls within operating hours (8 am- 10 PM EST)
         */

        LocalTime operatingHoursStart = LocalTime.of(8, 0);
        LocalTime operatingHoursEnd = LocalTime.of(22, 0);
        ZoneId estZone = ZoneId.of("America/New_York");
        ZonedDateTime startDateTimeEST = ZonedDateTime.of(startDate, startTime, estZone);
        ZonedDateTime endDateTimeEST = ZonedDateTime.of(endDate, endTime, estZone);

        if (startDateTimeEST.toLocalTime().isBefore(operatingHoursStart) ||
                endDateTimeEST.toLocalTime().isAfter(operatingHoursEnd)) {
            showErrorMessage(wrongTime);
            return;
        }

        /**
         * Checks if the appointment falls on a weekend (Saturday or Sunday)
         */

        if (startDate.getDayOfWeek() == DayOfWeek.SATURDAY || startDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
            showErrorMessage(wrongDateMessage);
            return;
        }

        /**
         * Checks if the appointment overlaps with existing appointments
         */

        if (AppointmentDB.overlappingAppointment(0, location, startDate, startTime)) {
            showErrorMessage(badapptime);
            return;
        }

        int contactID = getContactID(contact);
        if (AppointmentDB.Appointmentconflict(0, contactID , location,startDate,startTime)) {
           showErrorMessage(badapptime);
           return;
        }

        /**
         * Saves the appointment to the database
         */

        boolean saved = AppointmentDB.saveAppointment(customerID, title, description, type, contactID, location, startDate, startTime, userID);
        if (!saved) {
            showErrorMessage(failsave);
            return;
        }

        /**
         * Returns the user to the appointment main screen
         */

        try {
            Parent root = FXMLLoader.load(getClass().getResource("/Appointmentmain.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method used to return the correct ContactID based on the name selected from the combo box for Contact
     * @param contactName
     * @return
     */

    private int getContactID(String contactName) {
        switch (contactName) {
            case "Anika Costa":
                return 1;
            case "Daniel Garcia":
                return 2;
            case "Li Lee":
                return 3;
            default:
                return 0;
        }
    }

    /**
     * Handles the cancel button action, redirects the user to the appointment main screen
     * @param event
     */

    @FXML
    void cancelButton(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/Appointmentmain.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Handles the error message when it is displayed
     * @param message
     */

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(errorTitle);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void initialize(URL location, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        appID.setText(resourceBundle.getString("appointmentID"));
        custID.setText(resourceBundle.getString("customerIDlabel"));
        userID.setText(resourceBundle.getString("userID"));
        appTitle.setText(resourceBundle.getString("titlelabel"));
        appDesc.setText(resourceBundle.getString("descriptionlabel"));
        appLocation.setText(resourceBundle.getString("locationtag"));
        appContact.setText(resourceBundle.getString("contactlabel"));
        appStart.setText(resourceBundle.getString("startdate"));
        appEnd.setText(resourceBundle.getString("enddate"));
        appType.setText(resourceBundle.getString("apptype"));
        appStartTime.setText(resourceBundle.getString("starttime"));
        appEndTime.setText(resourceBundle.getString("endtime"));
        AddButton.setText(resourceBundle.getString("addbutton"));
        CancelButton.setText(resourceBundle.getString("cancelButton"));
        addAppLabel.setText(resourceBundle.getString("addapp"));
        errorTitle = resourceBundle.getString("errortitle");
        wrongTime = resourceBundle.getString("wrongTime");
        wrongDateMessage = resourceBundle.getString("wrongdatemessage");
        fillinfo = resourceBundle.getString("fillinfo");
        badapptime = resourceBundle.getString("badapptime");
        failsave = resourceBundle.getString("failsave");

        StartTime.setItems(times);
        EndTime.setItems(times);
        AppointmentType.setItems(type);
        ContactBox.setItems(contact);
    }
}
