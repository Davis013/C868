package davis.c195.Models;

import java.sql.*;

import davis.c195.helper.JDBC;
import davis.c195.helper.Log;

/**
 * Model for User Database functions
 * @author Brandon Davis
 */
public class UserDB {
    private static final String SELECT_USER_QUERY = "SELECT * FROM users WHERE User_Name = ? AND Password = ?";

    public static boolean Login(String username, String password) {
        try (Connection connection = JDBC.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_USER_QUERY)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            boolean isValidUser = resultSet.next(); // If there's a matching user, return true

            /**
             * Log the login attempt
             */
            Log.log(username, isValidUser);

            return isValidUser;
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return false;
        }
    }
}
