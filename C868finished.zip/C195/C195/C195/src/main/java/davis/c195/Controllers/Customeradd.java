package davis.c195.Controllers;

import davis.c195.Models.CustomerDB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for Customer Add Screen
 * @author Brandon Davis
 */


public class Customeradd implements Initializable {

    @FXML
    private TextField AddressText;

    @FXML
    private ComboBox<String> CityBox;

    @FXML
    private ComboBox<String> CountryBox;

    @FXML
    private TextField NameText;

    @FXML
    private TextField PhoneText;

    @FXML
    private TextField PostalText;
    @FXML
    private Text addCustLabel;
    @FXML
    private Text custName;
    @FXML
    private Text custAddress;
    @FXML
    private Text custPhone;
    @FXML
    private Text custCountry;
    @FXML
    private Text custCity;
    @FXML
    private Text custPostal;
    @FXML
    private Button Savebutton;
    @FXML
    private Button Cancelbutton;
    @FXML
    private Text custID;

    private String errortitle;
    private String missinginfo;
    private String missinginfotext;
    private String wrongcity;
    private String wrongcitytext;
    private String successtitle;
    private String success;
    private String successtext;
    private String addfail;
    private String addfailtext;


    /**
     * Method for listing all available city options
     */
    private ObservableList<String> UKCities = FXCollections.observableArrayList("Northern Ireland", "Scotland", "Wales", "England");
    private ObservableList<String> CanadaCities = FXCollections.observableArrayList("Newfoundland and Labrador", "Yukon", "Nunavut", "Saskatchewan", "Ontario",
            "Quebec", "Prince Edward Island", "Nova Scotia", "New Brunswick", "Manitoba", "British Columbia", "Alberta", "Northwest Territories");
    private ObservableList<String> USCities = FXCollections.observableArrayList("Alabama", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia",
            "Florida", "Georgia", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi",
            "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania",
            "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming", "Hawaii", "Alaska");
    String[] CountryOptions = {"United States", "Canada", "United Kingdom"};

    /**
     * Method for setting the country combo box
     */

    @FXML
    public void setCountry() {
        String selectedCountry = CountryBox.getValue();
        updateCityOptions(selectedCountry);
    }

    /**
     * Method to control what cities are viewed in the cities combo box based on the selected country
     * @param selectedCountry
     */

    private void updateCityOptions(String selectedCountry) {
        CityBox.getItems().clear();
        switch (selectedCountry) {
            case "United States":
                CityBox.setItems(FXCollections.observableArrayList(USCities));
                break;
            case "Canada":
                CityBox.setItems(FXCollections.observableArrayList(CanadaCities));
                break;
            case "United Kingdom":
                CityBox.setItems(FXCollections.observableArrayList(UKCities));
                break;
            default:
                break;
        }
    }

    /**
     * Handles cancel button action, this redirects the user back to the customer main screen
     * @param event
     * @throws IOException
     */

    @FXML
    void cancelButtonAction(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Customermain.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Handles the save button action, this saves the customer information to the database on successful attempts. On unsuccessful attempts displays error
     * @param event
     * @return
     */
    @FXML
    public boolean saveButtonAction(ActionEvent event) {
        String customerName = NameText.getText();
        String address = AddressText.getText();
        String phone = PhoneText.getText();
        String cityName = CityBox.getValue();
        String postalCode = PostalText.getText();

        if (customerName.isEmpty() || address.isEmpty() || phone.isEmpty() || cityName == null || postalCode.isEmpty()) {

            /**
             * Display an error message for missing fields
             */

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(errortitle);
            alert.setHeaderText(missinginfo);
            alert.setContentText(missinginfotext);
            alert.showAndWait();
            return false;
        } else {

            /**
             * Retrieve the division ID based on the selected city
             */

            String divisionID = CustomerDB.getDivisionID(cityName);

            if (divisionID == null) {

                /**
                 * Handle the case where the division ID is not found
                 */

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(errortitle);
                alert.setHeaderText(wrongcity);
                alert.setContentText(wrongcitytext);
                alert.showAndWait();
                return false;
            }

            /**
             * Calls the saveCustomer method to update the database with the new customer information
             */

            if (CustomerDB.saveCustomer(customerName, address, Integer.parseInt(divisionID), postalCode, phone)) {

                /**
                 * Displays success message
                 */

                Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                successAlert.setTitle(successtitle);
                successAlert.setHeaderText(success);
                successAlert.setContentText(successtext);
                successAlert.showAndWait();

                return true;
            } else {

                /**
                 * Handles the case where the customer addition fails
                 */

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(errortitle);
                alert.setHeaderText(addfail);
                alert.setContentText(addfailtext);
                alert.showAndWait();
                return false;
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        addCustLabel.setText(resourceBundle.getString("addcusttable"));
        custName.setText(resourceBundle.getString("namelabel"));
        custAddress.setText(resourceBundle.getString("addresslabel"));
        custPhone.setText(resourceBundle.getString("phonelabel"));
        custCountry.setText(resourceBundle.getString("countrylabel"));
        custCity.setText(resourceBundle.getString("citylabel"));
        custPostal.setText(resourceBundle.getString("postalcode"));
        Savebutton.setText(resourceBundle.getString("savebutton"));
        Cancelbutton.setText(resourceBundle.getString("cancelButton"));
        custID.setText(resourceBundle.getString("customerIDlabel"));
        errortitle = resourceBundle.getString("errortitle");
        missinginfo = resourceBundle.getString("missinginfo");
        missinginfotext = resourceBundle.getString("missinginfotext");
        wrongcity = resourceBundle.getString("wrongcity");
        wrongcitytext = resourceBundle.getString("wrongcitytext");
        successtitle = resourceBundle.getString("successtitle");
        success = resourceBundle.getString("success");
        successtext = resourceBundle.getString("successtext");
        addfail = resourceBundle.getString("addfail");
        addfailtext = resourceBundle.getString("addfailtext");
        CountryBox.setItems(FXCollections.observableArrayList(CountryOptions));
        CountryBox.setOnAction(e -> setCountry());
    }
}


