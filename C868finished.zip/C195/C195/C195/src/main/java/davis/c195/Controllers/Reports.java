package davis.c195.Controllers;

import davis.c195.helper.JDBC;
import davis.c195.Models.Appointment;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for Reports
 * @author Brandon Davis
 */

public class Reports implements Initializable {
    @FXML
    private RadioButton ContactSchedulebutton;

    @FXML
    private TableView<Appointment> ReportsTable;

    @FXML
    private RadioButton TotalbyMthButton;

    @FXML
    private RadioButton TotalbyTypeButton;

    @FXML
    private RadioButton AppbyCountryButton;
    @FXML
    private Button CancelButton;
    @FXML
    private Text reportsLabel;

    private String type;
    private String total;
    private String month;
    private String customerTitle;
    private String appID;
    private String custID;
    private String title;
    private String description;
    private String start;
    private String end;
    private String contact;
    private String country;
    private String Locations;



    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        JDBC.openConnection();
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        reportsLabel.setText(resourceBundle.getString("reportslabel"));
        CancelButton.setText(resourceBundle.getString("cancelButton"));
        TotalbyTypeButton.setText(resourceBundle.getString("totalbytype"));
        TotalbyMthButton.setText(resourceBundle.getString("totalmonthly"));
        AppbyCountryButton.setText(resourceBundle.getString("appbycountry"));
        ContactSchedulebutton.setText(resourceBundle.getString("contactsch"));
        type = resourceBundle.getString("typelabel");
        total = resourceBundle.getString("total");
        month = resourceBundle.getString("monthlabel");
        customerTitle = resourceBundle.getString("customerTitle");
        appID = resourceBundle.getString("appointmentID");
        custID = resourceBundle.getString("customerIDlabel");
        title = resourceBundle.getString("titlelabel");
        description = resourceBundle.getString("descriptionlabel");
        start = resourceBundle.getString("startlabel");
        end = resourceBundle.getString("endlabel");
        contact = resourceBundle.getString("contactname");
        country = resourceBundle.getString("countrylabel");
        Locations = resourceBundle.getString("locationtag");

        /**
         * Set up the radio button selection change listener
         */
        ToggleGroup toggleGroup = new ToggleGroup();
        TotalbyTypeButton.setToggleGroup(toggleGroup);
        TotalbyMthButton.setToggleGroup(toggleGroup);
        ContactSchedulebutton.setToggleGroup(toggleGroup);
        AppbyCountryButton.setToggleGroup(toggleGroup);

        toggleGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null) {
                return;
            }

            RadioButton selectedRadioButton = (RadioButton) newValue;
            populateTableView(selectedRadioButton);
        });

        displayContactSchedule();
    }
    /**
     * populates the table view with information based on which radio button is selected
     * @param selectedRadioButton
     */
    private void populateTableView(RadioButton selectedRadioButton) {
        if (selectedRadioButton == TotalbyTypeButton) {
            displayTotalByType();
        } else if (selectedRadioButton == TotalbyMthButton) {
            displayTotalByMonth();
        } else if (selectedRadioButton == ContactSchedulebutton) {
            displayContactSchedule();
        } else if (selectedRadioButton == AppbyCountryButton) {
            displayAppointmentByCountry();
        }
    }

    /**
     * The SQL query for Total by Type
     * @return
     */
    private ObservableList<Appointment> getTotalAppointmentsByType() {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        try {
            Connection connection = JDBC.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT Type, COUNT(*) AS TotalAppointments " + "FROM appointments " + "GROUP BY Type " + "ORDER BY Type;";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String type = resultSet.getString("Type");
                int total = resultSet.getInt("TotalAppointments");
                Appointment appointment = new Appointment(total, 0, "", "", "", "", "", "", type, 0 );
                appointments.add(appointment);
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return appointments;
    }

    /**
     * SQL query for Total by Month
     * @return
     */
    private ObservableList<Appointment> getTotalAppointmentsByMonth() {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        try {
            Connection connection = JDBC.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT MONTH(Start) AS Month, COUNT(*) AS Total FROM appointments GROUP BY MONTH(Start) ORDER BY MONTH(Start)";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String month = resultSet.getString("Month");
                int total = resultSet.getInt("Total");
                Appointment appointment = new Appointment(total, 0, month, "", "", "", "", "", "", 0);
                appointments.add(appointment);

            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return appointments;
    }


    /**
     * SQL query for appointments by country
     * @return
     */
    private ObservableList<Appointment> getAppointmentsByCountry() {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        try {
            Connection connection = JDBC.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT a.Appointment_ID, a.Title, a.Description, a.Location, a.Type, a.Start, a.End, a.Customer_ID, a.User_ID, a.Contact_ID, co.Country, cn.Contact_Name " +
                    "FROM appointments a " +
                    "JOIN customers c ON a.Customer_ID = c.Customer_ID " +
                    "JOIN first_level_divisions d ON c.Division_ID = d.Division_ID " +
                    "JOIN countries co ON d.Country_ID = co.Country_ID " +
                    "JOIN contacts cn ON a.Contact_ID = cn.Contact_ID " +
                    "ORDER BY co.Country;";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int appointmentID = resultSet.getInt("Appointment_ID");
                int customerID = resultSet.getInt("Customer_ID");
                String title = resultSet.getString("Title");
                String type = resultSet.getString("Type");
                String description = resultSet.getString("Description");
                String start = resultSet.getString("Start");
                String end = resultSet.getString("End");
                String contact = resultSet.getString("Contact_Name");
                String country = resultSet.getString("Country");
                Appointment appointment = new Appointment(appointmentID, customerID, start, end, title, description, country, contact, type, 0);
                appointments.add(appointment);
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return appointments;
    }

    /**
     * SQL query for the contact schedule
     * @return
     */
    private ObservableList<Appointment> getContactSchedule() {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        try {
            Connection connection = JDBC.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT a.Appointment_ID, a.Title, a.Description, a.Location, a.Type, a.Start, a.End, a.Customer_ID, a.User_ID, a.Contact_ID, c.Contact_Name " +
                    "FROM appointments a " +
                    "JOIN contacts c ON a.Contact_ID = c.Contact_ID " +
                    "ORDER BY c.Contact_Name;";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int appointmentID = resultSet.getInt("Appointment_ID");
                String title = resultSet.getString("Title");
                String type = resultSet.getString("Type");
                String description = resultSet.getString("Description");
                String start = resultSet.getString("Start");
                String end = resultSet.getString("End");
                String location = resultSet.getString("Location");
                int customerID = resultSet.getInt("Customer_ID");
                String contactName = resultSet.getString("Contact_Name");
                Appointment appointment = new Appointment(appointmentID, customerID, start, end, title, description, location, contactName, type, 0);
                appointments.add(appointment);
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return appointments;
    }

    /**
     * Fills the table view with data for total by type
     */
    private void displayTotalByType() {
        ObservableList<Appointment> appointments = getTotalAppointmentsByType();
        setTableColumnsForTotalByType();
        ReportsTable.setItems(appointments);
    }

    /**
     * Fills the table view with data for total by month
     */
    private void displayTotalByMonth() {
        ObservableList<Appointment> appointments = getTotalAppointmentsByMonth();
        setTableColumnsForTotalbyMonth();
        ReportsTable.setItems(appointments);
    }

    /**
     * Fills the table view with the data for contact schedule
     */
    private void displayContactSchedule() {
        ObservableList<Appointment> appointments = getContactSchedule();
        setTableColumnsForContactSchedule();
        ReportsTable.setItems(appointments);
    }

    /**
     * Fills the table view with the data for appointment by country
     */
    private void displayAppointmentByCountry() {
        ObservableList<Appointment> appointments = getAppointmentsByCountry();
        setTableColumnsForAppointmentByCountry();
        ReportsTable.setItems(appointments);
    }

    /**
     * Sets the table columns for total by type
     */
    private void setTableColumnsForTotalByType() {
        ReportsTable.getColumns().clear();

        TableColumn<Appointment, String> Type = new TableColumn<>(type);
        TableColumn<Appointment, Integer> AppointmentID = new TableColumn<>(total);



        AppointmentID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        Type.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType()));



        ReportsTable.getColumns().addAll(Type, AppointmentID);

    }

    /**
     * Sets the table columns for total by month
     */
    private void setTableColumnsForTotalbyMonth() {
        ReportsTable.getColumns().clear();

        TableColumn<Appointment, String> Start = new TableColumn<>(month);
        TableColumn<Appointment, Integer> AppointmentID = new TableColumn<>(total);


        AppointmentID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        Start.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStart()));



        ReportsTable.getColumns().addAll(Start, AppointmentID);

    }

    /**
     * Sets the table columns for contact schedule
     */
    private void setTableColumnsForContactSchedule() {
        ReportsTable.getColumns().clear();

        TableColumn<Appointment, Integer> AppointmentID = new TableColumn<>(appID);
        TableColumn<Appointment, String> Title = new TableColumn<>(title);
        TableColumn<Appointment, String> Description = new TableColumn<>(description);
        TableColumn<Appointment, String> Location = new TableColumn<>(Locations);
        TableColumn<Appointment, String> Type = new TableColumn<>(type);
        TableColumn<Appointment, String> Start = new TableColumn<>(start);
        TableColumn<Appointment, String> End = new TableColumn<>(end);
        TableColumn<Appointment, Integer> CustomerID = new TableColumn<>(custID);
        TableColumn<Appointment, String> Contact = new TableColumn<>(contact);


        AppointmentID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        Title.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle()));
        Description.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescription()));
        Location.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getLocation()));
        Type.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType()));
        Start.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStart()));
        End.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEnd()));
        CustomerID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getCustomerID()).asObject());
        Contact.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getContact()));


        ReportsTable.getColumns().addAll(AppointmentID, Title, Description, Location,
                Type, Start, End, CustomerID,
                 Contact);

    }

    /**
     * Sets table columns for appointment by country
     */
    private void setTableColumnsForAppointmentByCountry() {
        ReportsTable.getColumns().clear();

        TableColumn<Appointment, Integer> AppointmentID = new TableColumn<>(appID);
        TableColumn<Appointment, String> Title = new TableColumn<>(title);
        TableColumn<Appointment, String> Description = new TableColumn<>(description);
        TableColumn<Appointment, String> Location = new TableColumn<>(country);
        TableColumn<Appointment, String> Type = new TableColumn<>(type);
        TableColumn<Appointment, String> Start = new TableColumn<>(start);
        TableColumn<Appointment, String> End = new TableColumn<>(end);
        TableColumn<Appointment, Integer> CustomerID = new TableColumn<>(custID);
        TableColumn<Appointment, String> Contact = new TableColumn<>(contact);


        AppointmentID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        Title.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle()));
        Description.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescription()));
        Location.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getLocation()));
        Type.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType()));
        Start.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStart()));
        End.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEnd()));
        CustomerID.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getCustomerID()).asObject());
        Contact.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getContact()));


        ReportsTable.getColumns().addAll(AppointmentID, Title, Description, Location,
                Type, Start, End, CustomerID,
                Contact);

    }


    /**
     * Controls the cancel button action returning you to the main screen
     * @param event
     * @throws IOException
     */
    @FXML
    private void cancelButton (ActionEvent event) throws IOException{
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mainscreen.fxml"));
        Parent root = loader.load();
        stage.setTitle(customerTitle);
        stage.setScene(new Scene(root));
        stage.show();

    }
}


