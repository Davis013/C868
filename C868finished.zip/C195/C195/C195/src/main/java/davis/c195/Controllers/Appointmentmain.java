package davis.c195.Controllers;

import davis.c195.Models.Appointment;
import davis.c195.Models.AppointmentDB;
import davis.c195.Models.Customer;
import davis.c195.Models.CustomerDB;
import davis.c195.helper.JDBC;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for Appointment Main
 * @author Brandon Davis
 */

public class Appointmentmain implements Initializable {


    @FXML
    private TableView<Appointment> AppointmentTable;

    @FXML
    private TableColumn<Appointment, Integer> AppointmentID;

    @FXML
    private TableColumn<Appointment, String> Title;

    @FXML
    private TableColumn<Appointment, String> Description;

    @FXML
    private TableColumn<Appointment, String> Location;

    @FXML
    private TableColumn<Appointment, String> Contact;

    @FXML
    private TableColumn<Appointment, String> Type;

    @FXML
    private TableColumn<Appointment, String> Start;

    @FXML
    private TableColumn<Appointment, String> End;

    @FXML
    private TableColumn<Appointment, Integer> UserID;

    @FXML
    private TableView<Customer> CustomerTable;

    @FXML
    private TableColumn<Customer, Integer> customerID;

    @FXML
    private TableColumn<Customer, String> customerName;

    @FXML
    private RadioButton AppMonthlyButton;

    @FXML
    private RadioButton AppWeeklyButton;

    @FXML
    private RadioButton allAppointmentsButton;

    @FXML
    private TableColumn<Appointment, Integer> CustomerID;

    @FXML
    private Text appMainLabel;
    @FXML
    private Button AddAppointment;
    @FXML
    private Button DeleteAppointment;
    @FXML
    private Button ModifyAppointment;
    @FXML
    private Button CancelButton;
    @FXML
    private Text appSearchLabel;
    @FXML
    private TextField appointmentSearchBar;

    private Appointment selectedAppointment;
    private String deleteAppMessage;
    private String deleteAppID;
    private String deleteAppType;
    private String deleteCustomerTitle;

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        JDBC.openConnection();

        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        appMainLabel.setText(resourceBundle.getString("apphome"));
        AppointmentID.setText(resourceBundle.getString("appointmentID"));
        Title.setText(resourceBundle.getString("titlelabel"));
        Description.setText(resourceBundle.getString("descriptionlabel"));
        Location.setText(resourceBundle.getString("locationtag"));
        Contact.setText(resourceBundle.getString("contactlabel"));
        Type.setText(resourceBundle.getString("typelabel"));
        Start.setText(resourceBundle.getString("startlabel"));
        End.setText(resourceBundle.getString("endlabel"));
        UserID.setText(resourceBundle.getString("userID"));
        CustomerID.setText(resourceBundle.getString("customerIDlabel"));
        customerID.setText(resourceBundle.getString("customerIDlabel"));
        customerName.setText(resourceBundle.getString("customernamelabel"));
        AppMonthlyButton.setText(resourceBundle.getString("appsmth"));
        AppWeeklyButton.setText(resourceBundle.getString("appswkly"));
        allAppointmentsButton.setText(resourceBundle.getString("allapps"));
        AddAppointment.setText(resourceBundle.getString("addapp"));
        ModifyAppointment.setText(resourceBundle.getString("modapp"));
        DeleteAppointment.setText(resourceBundle.getString("delapp"));
        CancelButton.setText(resourceBundle.getString("cancelButton"));
        appSearchLabel.setText(resourceBundle.getString("searchLabel"));
        deleteAppID = resourceBundle.getString("deleteAppID");
        deleteAppMessage = resourceBundle.getString("deleteAppointmentMessage");
        deleteAppType = resourceBundle.getString("deleteAppType");
        deleteCustomerTitle = resourceBundle.getString("deleteCustomerTitle");

        appointmentSearchBar.textProperty().addListener((observable, oldValue, newValue) ->{
            try {
                filterApps(newValue);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        /**
         *Initializes the table columns
         * Lambda function # 2: Used to specify how the cell values in the tableview should be populated
         */

        AppointmentID.setCellValueFactory(cellData -> cellData.getValue().getAppointmentIDProperty().asObject());
        Title.setCellValueFactory(cellData -> cellData.getValue().getTitleProperty());
        Description.setCellValueFactory(cellData -> cellData.getValue().getDescriptionProperty());
        Location.setCellValueFactory(cellData -> cellData.getValue().getLocationProperty());
        Contact.setCellValueFactory(cellData -> cellData.getValue().getContactProperty());
        Type.setCellValueFactory(cellData -> cellData.getValue().getTypeProperty());
        Start.setCellValueFactory(cellData -> cellData.getValue().getStartProperty());
        End.setCellValueFactory(cellData -> cellData.getValue().getEndProperty());
        UserID.setCellValueFactory(cellData -> cellData.getValue().getUserIDProperty().asObject());
        CustomerID.setCellValueFactory(cellData -> cellData.getValue().getCustomerIDProperty().asObject());

        customerID.setCellValueFactory(cellData -> cellData.getValue().getCustomerIDProperty().asObject());
        customerName.setCellValueFactory(cellData -> cellData.getValue().getCustomerNameProperty());

        /**
         * Creates toggle group for the filter radio buttons
         */

        ToggleGroup filterToggleGroup = new ToggleGroup();
        AppMonthlyButton.setToggleGroup(filterToggleGroup);
        AppWeeklyButton.setToggleGroup(filterToggleGroup);
        allAppointmentsButton.setToggleGroup(filterToggleGroup);

        /**
         * Adds a listener to the toggle group to handle selection changes
         */

        filterToggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                if (newValue == AppMonthlyButton) {
                    /**
                     * Filter for monthly appointments
                     */
                    filterAppointments("month");
                } else if (newValue == AppWeeklyButton) {
                    /**
                     * Filter for weekly appointments
                     */
                    filterAppointments("week");
                } else if (newValue == allAppointmentsButton) {
                    /**
                     * Filter for all appointments
                     */
                    filterAppointments("");
                }
            }
        });

        /**
         * Loads initial data
         */
        try {
            ObservableList<Appointment> appointments = AppointmentDB.getAllAppointments("");
            AppointmentTable.setItems(appointments);
            ObservableList<Customer> customers = CustomerDB.getAllCustomers();
            CustomerTable.setItems(customers);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the add button on appointment main to redirect the user to the Add Appointment screen
     *
     * @param event
     * @throws IOException
     */

    @FXML
    private void addAppointmentButton(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/AppointmentAdd.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    /**
     * Handles the delete button action
     *
     * @param event
     */

    @FXML
    private void deleteAppointmentButton(ActionEvent event) {

        if (AppointmentTable.getSelectionModel().getSelectedItem() != null) {

            selectedAppointment = AppointmentTable.getSelectionModel().getSelectedItem();
        } else {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(deleteCustomerTitle);
        alert.setContentText(deleteAppMessage + " " + deleteAppID + " " + selectedAppointment.getAppointmentID() + " " + deleteAppType + " " + selectedAppointment.getType() + "?");
        Optional<ButtonType> result = alert.showAndWait();

        /**
         * Lambda Function # 3 used to simplify deletion process
         */

        result.ifPresent(buttonType -> {
            if (buttonType == ButtonType.OK) {
                AppointmentDB.deleteAppointment(selectedAppointment.getAppointmentID());

                try {
                    AppointmentTable.setItems(AppointmentDB.getAllAppointments(""));
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

            }


        });

    }

    /**
     * Handles modify button action and redirects the user to Appointment Modify screen. If no appointment is selected you will not be able to use the modify button
     *
     * @param event
     * @throws IOException
     */

    @FXML
    private void modifyAppointmentButton(ActionEvent event) throws IOException {

        if (AppointmentTable.getSelectionModel().getSelectedItem() != null) {
            selectedAppointment = AppointmentTable.getSelectionModel().getSelectedItem();
        }

        /**
         * Retrieves the selected appointment ID
         */

        int selectedApp = selectedAppointment.getAppointmentID();

        try {

            /**
             * Establish database connection
             */

            Connection connection = JDBC.getConnection();

            /**
             * SQL query to retrieve appointment data
             */

            String query = "SELECT * FROM appointments WHERE Appointment_ID = ?";

            /**
             * Prepares the query statement
             */

            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, selectedApp);

            /**
             * Executes the query
             */

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {

                /**
                 * Retrieves appointment information from the result set
                 */

                int appointmentID = resultSet.getInt("Appointment_ID");
                int customerID = resultSet.getInt("Customer_ID");
                int userID = resultSet.getInt("User_ID");
                String description = resultSet.getString("Description");
                String type = resultSet.getString("Type");
                String title = resultSet.getString("Title");
                String contact = resultSet.getString("Contact_ID");
                String location = resultSet.getString("Location");
                String start = resultSet.getString("Start");
                String end = resultSet.getString("End");

                /**
                 * Parse the Start and End strings into LocalDateTime objects
                 */

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime startDateTime = LocalDateTime.parse(start, formatter);
                LocalDateTime endDateTime = LocalDateTime.parse(end, formatter);

                /**
                 * Extracts the date and time components
                 */

                LocalDate startDate = startDateTime.toLocalDate();
                LocalTime startTime = startDateTime.toLocalTime();
                LocalDate endDate = endDateTime.toLocalDate();
                LocalTime endTime = endDateTime.toLocalTime();

                /**
                 * Pass the appointment information to the AppointmentModify Screen
                 */

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/AppointmentModify.fxml"));
                Parent parent = loader.load();
                Appointmentmodify controller = loader.getController();
                controller.setAppointmentInformation(appointmentID, customerID, userID, title, description, type, contact, location, startDate, startTime, endDate, endTime);

                /**
                 * Creates new scene
                 */

                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * Handles the cancel button action, redirects user back to the main screen
     *
     * @param event
     * @throws IOException
     */

    @FXML
    private void cancelButton(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mainscreen.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Handles the filter between monthly weekly and all
     *
     * @param filter
     */

    private void filterAppointments(String filter) {
        try {
            ObservableList<Appointment> appointments = AppointmentDB.getAllAppointments(filter);
            AppointmentTable.setItems(appointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void filterApps(String keyword) throws SQLException {
        ObservableList<Customer> allCustomers = CustomerDB.getAllCustomers();
        ObservableList<Customer> filteredCustomers = FXCollections.observableArrayList();
        ObservableList<Appointment> allAppointments = AppointmentDB.getAllAppointments("");
        ObservableList<Appointment> filteredApps = FXCollections.observableArrayList();
        for (Customer customer : allCustomers) {

            if (customer.getCustomerName().toLowerCase().contains(keyword.toLowerCase())) {
                filteredCustomers.add(customer);
            }
        }
        for (Appointment appointment: allAppointments){
            for (Customer customer : filteredCustomers){
                if (appointment.getCustomerID() == customer.getCustomerID()){
                    filteredApps.add(appointment);
                    break;
                }
            }
        }
        CustomerTable.setItems(filteredCustomers);
        AppointmentTable.setItems(filteredApps);
    }
}