package davis.c195.Models;

import davis.c195.helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Model for Customer Database functions
 * @author Brandon Davis
 */

public class CustomerDB {
    private static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

    /**
     * Returns all customers in the Database
     *
     * @return ObservableList of customers
     */
    public static ObservableList<Customer> getAllCustomers() {
        allCustomers.clear();
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT customer.Customer_ID, customer.Customer_Name, customer.Address, customer.Postal_Code, customer.Phone, division.Division_ID, division.Division "
                    + "FROM customers AS customer "
                    + "INNER JOIN first_level_divisions AS division ON customer.Division_ID = division.Division_ID";
            ResultSet results = statement.executeQuery(query);
            while (results.next()) {
                Customer customer = new Customer(
                        results.getInt("Customer_ID"),
                        results.getString("Customer_Name"),
                        results.getString("Address"),
                        results.getString("Postal_Code"),
                        results.getString("Phone"),
                        results.getString("Division_ID"),
                        results.getString("Division")
                );
                allCustomers.add(customer);
            }
            statement.close();
            return allCustomers;
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return null;
        }
    }

    /**
     * Saves Customer to the Database
     *
     * @param customerName
     * @param address
     * @param divisionID
     * @param postalCode
     * @param phone
     *
     */
    public static boolean saveCustomer(String customerName, String address, int divisionID, String postalCode, String phone) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String queryOne = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES ('" +
                    customerName + "', '" + address + "', '" + postalCode + "', '" + phone + "', " + divisionID + ")";
            int updateOne = statement.executeUpdate(queryOne);
            if (updateOne == 1) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }



    /**
     * Update existing Customer in Database
     *
     * @param customerID
     * @param customerName
     * @param address
     * @param divisionName
     * @param postalCode
     * @param phone
     *
     */
    public static boolean updateCustomer(int customerID, String customerName, String address, String phone, String postalCode, String divisionName) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            // Retrieve the Division_ID based on the selected divisionName
            String divisionQuery = "SELECT Division_ID FROM first_level_divisions WHERE Division='" + divisionName + "'";
            ResultSet divisionResult = statement.executeQuery(divisionQuery);
            int divisionID = -1;  // Default value in case no division is found
            if (divisionResult.next()) {
                divisionID = divisionResult.getInt("Division_ID");
            }

            // Update the customer information including the Division_ID
            String updateQuery = "UPDATE customers SET Customer_Name='" + customerName + "', Address='" + address +
                    "', Phone='" + phone + "', Postal_Code='" + postalCode +
                    "', Division_ID=" + divisionID +
                    " WHERE Customer_ID=" + customerID;

            int rowsAffected = statement.executeUpdate(updateQuery);
            statement.close();
            return rowsAffected == 1;
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return false;
        }
    }

    /**
     * Delete Customer from Database
     *
     * @param customerID
     */
    public static boolean deleteCustomer(int customerID) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "DELETE FROM customers WHERE Customer_ID=" + customerID;
            int update = statement.executeUpdate(query);
            if (update == 1) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return false;
    }

    /**
     * Returns the division ID based on the selected city
     *
     * @param cityName Selected city name
     * @return The division ID if found
     */
    public static String getDivisionID(String cityName) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT Division_ID FROM first_level_divisions WHERE Division='" + cityName + "'";
            ResultSet results = statement.executeQuery(query);
            if (results.next()) {
                String divisionID = results.getString("Division_ID");
                statement.close();
                return divisionID;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return null;
    }

    /**
     * returns Division name based on division ID
     * @param divisionID
     * @return
     */
    public static String getDivisionName(String divisionID) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT Division FROM first_level_divisions WHERE Division_ID=" + divisionID;
            ResultSet results = statement.executeQuery(query);
            if (results.next()) {
                String divisionName = results.getString("Division");
                statement.close();
                return divisionName;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return null;
    }

    /**
     * Returns the country name based on the division name
     *
     * @param divisionName
     *
     */
    public static String getCountryByDivisionName(String divisionName) {
        try {
            Statement statement = JDBC.getConnection().createStatement();
            String query = "SELECT countries.Country FROM first_level_divisions " +
                    "INNER JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID " +
                    "WHERE first_level_divisions.Division = '" + divisionName + "'";
            ResultSet results = statement.executeQuery(query);
            if (results.next()) {
                String countryName = results.getString("Country");
                statement.close();
                return countryName;
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
        return "";
    }
}
