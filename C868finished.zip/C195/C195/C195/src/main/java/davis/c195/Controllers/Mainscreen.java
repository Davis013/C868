package davis.c195.Controllers;

import davis.c195.helper.JDBC;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Controller for Mainscreen
 * @author Brandon Davis
 */

public class Mainscreen implements Initializable {

    @FXML
    private Button Appointmentmanagerbutton;
    @FXML
    private Button CustomermanagerButton;
    @FXML
    private Button reportsManagerButton;
    @FXML
    private Button loginManagerButton;
    @FXML
    private Button ExitButton;
    @FXML
    private Text scheduleLabel;
    private String alerttitle;
    private String alertcontent;
    private String AlertTitle;
    private String alerttextID;
    private String alerttextName;
    private String alerttextStart;
    private String alertmessage;
    private String appointmentsTitle;
    private String customerTitle;
    private String reportsTitle;

    private Timer appointmentTimer;

    /**
     * handles the appointment manager action and redirects the user to the appointment main screen
     * @param event
     * @throws IOException
     */


    @FXML
    void Appointmentmanagerbutton(ActionEvent event) throws IOException{

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Appointmentmain.fxml"));
        Parent root = loader.load();
        stage.setTitle(appointmentsTitle);
        stage.setScene(new Scene(root));
        stage.show();


    }

    /**
     * handles the customer manager button action and redirects the user to the customer main screen
     * @param event
     * @throws IOException
     */

    @FXML
    void CustomermanagerButton(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Customermain.fxml"));
        Parent root = loader.load();
        stage.setTitle(customerTitle);
        stage.setScene(new Scene(root));
        stage.show();

    }

    /**
     * handles the exit button action
     * @param event
     */

    @FXML
    void Exitbutton(ActionEvent event) {

        System.exit(0);

    }


    /**
     * handles the login manager action, shows the login_activity of login attempts with the time stamps, successful and failed attempts, as well as location
     * @param event
     */
    @FXML
    void loginManagerButton (ActionEvent event) {
        File file = new File("login_activity.txt");
        try {
            if (file.exists()) {
                Runtime.getRuntime().exec("notepad " + "login_activity.txt");
            } else {
                System.out.println("File not found.");
            }

        } catch (IOException e) {

            System.out.println(" Error Opening Log File: " + e.getMessage());
        }
    }

    /**
     * handles the report manager action, redirects the user to the Reports menu where the 4 different reports can be viewed
     * @param event
     * @throws IOException
     */
    @FXML
    void reportsManagerButton (ActionEvent event) throws IOException{

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Reports.fxml"));
        Parent root = loader.load();
        stage.setTitle(reportsTitle);
        stage.setScene(new Scene(root));
        stage.show();



    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        JDBC.openConnection();
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        Appointmentmanagerbutton.setText(resourceBundle.getString("appointmentmanager"));
        CustomermanagerButton.setText(resourceBundle.getString("customermanager"));
        ExitButton.setText(resourceBundle.getString("exitmanager"));
        loginManagerButton.setText(resourceBundle.getString("loginmanager"));
        reportsManagerButton.setText(resourceBundle.getString("reportsmanager"));
        scheduleLabel.setText(resourceBundle.getString("schedulelabel"));
        alerttitle = resourceBundle.getString("alerttitle");
        alertcontent = resourceBundle.getString("alertcontent");
        AlertTitle = resourceBundle.getString("AlertTitle");
        alerttextID = resourceBundle.getString("alerttextID");
        alerttextName = resourceBundle.getString("alerttextName");
        alerttextStart = resourceBundle.getString("alerttextStart");
        alertmessage = resourceBundle.getString("alertmessage");
        appointmentsTitle = resourceBundle.getString("appointmentsTitle");
        customerTitle = resourceBundle.getString("customerTitle");
        reportsTitle = resourceBundle.getString("reportsTitle");
        startAppointmentTimer();
    }

    /**
     * starts a time that checks every 15 minutes for a new appointment if appointment is found it alerts user, if no appointment is found message is displayed in IDE stating no appointment in 15 minutes.
     * Lambda function #4: lambda function is used to simplify the run function in the code, be directly specifying the behavior of the run method.
     */
    private void startAppointmentTimer() {
        appointmentTimer = new Timer();

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                LocalDateTime currentTime = LocalDateTime.now();
                LocalDateTime fifteenMinutesLater = currentTime.plusMinutes(15);

                try (Connection connection = JDBC.getConnection()) {
                    String query = "SELECT * FROM appointments WHERE start BETWEEN ? AND ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setTimestamp(1, Timestamp.valueOf(currentTime));
                    statement.setTimestamp(2, Timestamp.valueOf(fifteenMinutesLater));

                    ResultSet resultSet = statement.executeQuery();

                    if (!resultSet.next()) {
                        /**
                         * No upcoming appointments
                         */
                        showNoAppointmentAlert();
                    } else {
                        do {
                            int AppointmentID = resultSet.getInt("Appointment_ID");
                            String CustomerName = resultSet.getString("Customer_Name");
                            LocalDateTime Start = resultSet.getTimestamp("Start").toLocalDateTime();

                            /**
                             * Shows appointment alert to the user
                             */
                            showAppointmentAlert(AppointmentID, CustomerName, Start);
                        } while (resultSet.next());
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        };
        /**
         * Schedule the task to run every 15 minutes
         */
        appointmentTimer.schedule(task, 0, 900_000);
    }

    /**
     * handles the alert for no appointments in 15 mintues
     * Lambda function # 5 : this lambda function is used to display the information message when Platform.runLater() is invoked with the lambda function as its argument. By using
     * this method it ensures that the UI updates and avoids potential threading issues in the JavaFX application
     */
    private void showNoAppointmentAlert() {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(alerttitle);
            alert.setHeaderText(null);
            alert.setContentText(alertcontent);

            /**
             * shows the alert dialog
             */
            alert.showAndWait();
        });
    }

    /**
     * handles alert if there is an appointment in 15 minutes
     * @param AppointmentID
     * @param CustomerName
     * @param Start
     * Lambda function # 6: this lambda function is used to display the information message when Platform.runLater() is invoked with the lambda function, it creates an alert dialog about the upcoming appointment. By using
     * this method it ensures that the UI updates and avoids potential threading issues in the JavaFX application
     */
    private void showAppointmentAlert(int AppointmentID, String CustomerName, LocalDateTime Start) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(AlertTitle);
            alert.setHeaderText(null);
            alert.setContentText(alerttextID + AppointmentID + "\n"
                    + alerttextName + CustomerName + "\n"
                    + alerttextStart + Start + "\n"
                    + alertmessage);

            /**
             * shows the alert dialog
             */
            alert.showAndWait();
        });

}
}
