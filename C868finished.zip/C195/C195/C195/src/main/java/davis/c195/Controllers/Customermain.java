package davis.c195.Controllers;

import davis.c195.Models.Customer;
import davis.c195.Models.CustomerDB;
import davis.c195.helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;


/**
 * Controller for Customer Mainscreen
 * @author Brandon Davis
 */

public class Customermain implements Initializable {

    @FXML
    private TableColumn<Customer,String> CityID;

    @FXML
    private TableColumn<Customer, Integer> CustomerID;

    @FXML
    private TableView<Customer> CustomerMainTable;

    @FXML
    private TableColumn<Customer, String> CustomerName;

    @FXML
    private Button Addbutton;
    @FXML
    private Button ModifyButton;
    @FXML
    private Button DeleteButton;
    @FXML
    private Button CancelButton;
    @FXML
    private Text customerSearchlabel;
    @FXML
    private Text custtblLabel;
    @FXML
    private TextField customerSearchBar;

    private Customer selectedCustomer;
    private String deleteCustomerTitle;
    private String deleteCustomerMessage;



    /**
     * Opens the Customer Add screen so user can add their information to the database
     * @param event
     * @throws IOException
     */
    @FXML
    void addButtonAction(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader (getClass().getResource("/CustomerAddscreen.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();


    }

    /**
     * This brings user back to the main screen, so they can either choose a different option from the menu or exit back to the login screen from here
     * @param event
     * @throws IOException
     */
    @FXML
    void cancelButtonAction(ActionEvent event) throws IOException{

        FXMLLoader loader = new FXMLLoader (getClass().getResource("/Mainscreen.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();



    }

    /**
     * Handles the delete button action, removes customer from the table
     * @param event
     */
    @FXML
    void deleteButtonAction(ActionEvent event) {
        if (CustomerMainTable.getSelectionModel().getSelectedItem() != null) {

            selectedCustomer = CustomerMainTable.getSelectionModel().getSelectedItem();
        } else {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(deleteCustomerTitle);
        alert.setContentText(deleteCustomerMessage + " " + selectedCustomer.getCustomerName() + "?");
        Optional<ButtonType> result = alert.showAndWait();
        /**
         * Lambda function # 1 Used to simplify the deletion process
         */
        result.ifPresent(buttonType -> {
            if (buttonType == ButtonType.OK) {
                CustomerDB.deleteCustomer(selectedCustomer.getCustomerID());

                CustomerMainTable.setItems(CustomerDB.getAllCustomers());

            }


        });
    }

    /**
     * Handles the modify button action, redirects the user to the customer update screen. If no customer is selected button cannot be used
     * @param event
     * @throws IOException
     */
    @FXML
    void modifyButtonAction(ActionEvent event) throws IOException {
        if (CustomerMainTable.getSelectionModel().getSelectedItem() != null)
        { selectedCustomer = CustomerMainTable.getSelectionModel().getSelectedItem();}

        else {
            return;
        }

        /**
         * Retrieves the selected Customers ID
         */

        int customerID = selectedCustomer.getCustomerID();

        try {
            /**
             * Establishes database connection
             */
            Connection connection = JDBC.getConnection();

            /**
             * Creates SQL query to gather Customer Data
             */

            String query = "SELECT * FROM Customers WHERE Customer_ID = ?";

            /**
             * Preparing the statement for execution
             */

            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerID);

            /**
             * Executes the query
             */

            ResultSet resultSet = statement.executeQuery();

            /**
             * Checks if there is a result
             */

            if (resultSet.next()) {

                /**
                 * Retrieves the customer information from the result set
                 */

                int CustomerID = resultSet.getInt("Customer_ID");
                String CustomerName = resultSet.getString("Customer_Name");
                String Address = resultSet.getString("Address");
                String Phone = resultSet.getString("Phone");
                String PostalCode = resultSet.getString("Postal_Code");
                String CityID = resultSet.getString("Division_ID");

                /**
                 * Passes the Customer information to the Customer Update screen
                 */

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/CustomerUpdatescreen.fxml"));
                Parent parent = loader.load();
                Customerupdate controller = loader.getController();
                controller.setCustomerInformation(CustomerID, CustomerName, Address, Phone, PostalCode, CityID);

                /**
                 * Creates new scene
                 */

                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void filterCustomers(String keyword) {
        ObservableList<Customer> allCustomers = CustomerDB.getAllCustomers();
        ObservableList<Customer> filteredCustomers = FXCollections.observableArrayList();

        for (Customer customer : allCustomers){

            if (customer.getCustomerName().toLowerCase().contains(keyword.toLowerCase())){
                filteredCustomers.add(customer);
            }
        }
        CustomerMainTable.setItems(filteredCustomers);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        JDBC.openConnection();
        Locale locale = Locale.getDefault();
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        Addbutton.setText(resourceBundle.getString("addbutton"));
        CancelButton.setText(resourceBundle.getString("cancelButton"));
        DeleteButton.setText(resourceBundle.getString("deletebutton"));
        ModifyButton.setText(resourceBundle.getString("modifybutton"));
        customerSearchlabel.setText(resourceBundle.getString("searchLabel"));
        custtblLabel.setText(resourceBundle.getString("custtablename"));
        deleteCustomerMessage = resourceBundle.getString("deleteCustomerMessage");
        deleteCustomerTitle = resourceBundle.getString("deleteCustomerTitle");
        CustomerID.setText(resourceBundle.getString("customerIDlabel"));
        CustomerName.setText(resourceBundle.getString("customernamelabel"));
        CityID.setText(resourceBundle.getString("territory"));
        CustomerID.setCellValueFactory(cellData -> cellData.getValue().getCustomerIDProperty().asObject());
        CustomerName.setCellValueFactory(cellData -> cellData.getValue().getCustomerNameProperty());
        CityID.setCellValueFactory(cellData -> cellData.getValue().getDivisionNameProperty());
        CustomerMainTable.setItems(CustomerDB.getAllCustomers());

        customerSearchBar.textProperty().addListener((observable, oldValue, newValue) -> {
            filterCustomers(newValue);
        });
    }
}

