package davis.c195.Models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 * Model for Customers information
 *
 * @author Brandon Davis
 */
public final class Customer {
    private final SimpleIntegerProperty CustomerID = new SimpleIntegerProperty();
    private final SimpleStringProperty CustomerName = new SimpleStringProperty();
    private final SimpleStringProperty Address = new SimpleStringProperty();
    private final SimpleStringProperty CityID = new SimpleStringProperty();
    private final SimpleStringProperty PostalCode = new SimpleStringProperty();
    private final SimpleStringProperty Phone = new SimpleStringProperty();

    private final SimpleStringProperty DivisionName = new SimpleStringProperty();


    /**
     * Constuctor for Customer Information
     *
     * @param CustomerID
     * @param CustomerName
     * @param Address
     * @param CityID
     * @param Phone
     * @param PostalCode
     * @param DivisionName
     */
    public Customer(int CustomerID, String CustomerName, String Address, String CityID, String Phone, String PostalCode, String DivisionName) {
        setCustomerID(CustomerID);
        setCustomerName(CustomerName);
        setCustomerAddress(Address);
        setCustomerCity(CityID);
        setCustomerPhone(Phone);
        setCustomerZip(PostalCode);
        setDivisionName(DivisionName);
    }

    /**
     * Getter for Customer ID
     * @return CustomerID
     */
    public int getCustomerID() {
        return CustomerID.get();
    }

    /**
     * Getter for Customer Name
     * @return CustomerName
     */
    public String getCustomerName() {
        return CustomerName.get();
    }

    /**
     * Getter for Address
     * @return Address
     */
    public String getAddress() {
        return Address.get();
    }

    /**
     * Getter for City ID
     * @return CityID
     */
    public String getCityID() {
        return CityID.get();
    }

    /**
     * Getter for Phone Number
     * @return Phone
     */
    public String getPhone() {
        return Phone.get();
    }

    /**
     * Getter for Postal Code
     * @return PostalCode
     */
    public String getPostalCode() {
        return PostalCode.get();
    }

    /**
     * Getter for Division Name
     * @return DivisionName
     */
    public String getDivisionName() {return DivisionName.get(); }

    /**
     * Setter for Customer ID
     * @param CustomerID
     */

    public void setCustomerID(int CustomerID) {
        this.CustomerID.set(CustomerID);
    }

    /**
     * Setter for Customer Name
     * @param CustomerName
     */
    public void setCustomerName(String CustomerName) {
        this.CustomerName.set(CustomerName);
    }

    /**
     * Setter for Address
     * @param Address
     */
    public void setCustomerAddress(String Address) {
        this.Address.set(Address);
    }

    /**
     * Setter for City ID
     * @param CityID
     */
    public void setCustomerCity(String CityID) {
        this.CityID.set(CityID);
    }

    /**
     * Setter for Phone Number
     * @param Phone
     */
    public void setCustomerPhone(String Phone) {
        this.Phone.set(Phone);
    }

    /**
     * Setter for PostalCode
     * @param PostalCode
     */
    public void setCustomerZip(String PostalCode) {
        this.PostalCode.set(PostalCode);
    }

    /**
     * Setter for DivisionName
     * @param DivisionName
     */
    public void setDivisionName(String DivisionName) {this.DivisionName.set(DivisionName);}

    /**
     * Getter property for CustomerID
     * @return CustomerID
     */
    public IntegerProperty getCustomerIDProperty() { return this.CustomerID;}

    /**
     * Getter property for CustomerName
     * @return
     */
    public StringProperty getCustomerNameProperty() {return this.CustomerName;}

    /**
     * Getter property for City ID
     * @return CityID
     */
    public StringProperty getCustomerCityProperty() {return this.CityID;}

    /**
     * Getter property for Division Name
     * @return DivisionName
     */
    public StringProperty getDivisionNameProperty() {return this.DivisionName;}
}

