package davis.c195.Controllers;


import davis.c195.Models.UserDB;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for login
 * @author Brandon Davis
 */

public class Login implements Initializable {

    @FXML
    private Button ExitButton;

    @FXML
    private TextArea Locationbox;

    @FXML
    private Button LoginButton;

    @FXML
    private Text PasswordLabel;

    @FXML
    private PasswordField PasswordText;

    @FXML
    private Text UsernameLabel;

    @FXML
    private TextField UsernameText;
    @FXML
    private Text loginLabel;

    private String errorHeader;
    private String errorTitle;
    private String errorText;

    /**
     * handles the exit button action
     * @param event
     */
    @FXML
    void ExitButton(ActionEvent event) {

        System.exit(0);

    }

    /**
     * handles the login button action, on successful attempts redirects the user to the mainscreen. On failed attempts displays error to user in the computers preferred language
     * @param event
     * @throws IOException
     */
    @FXML
    void LoginButton(ActionEvent event) throws IOException {

        String Username = UsernameText.getText();
        String Password = PasswordText.getText();
        boolean ValidUser= UserDB.Login(Username, Password);
        if (ValidUser) {
            ((Node) event.getSource()).getScene().getWindow();
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/Mainscreen.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(errorTitle);
            alert.setHeaderText(errorHeader);
            alert.setContentText(errorText);
            alert.showAndWait();
        }

    }

    /**
     * Information below handles the login screen information such as location and different elements of the login screen that needs to be changed when the preferred language is different then English
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        ZoneId Zone = ZoneId.systemDefault();
        Locationbox.setText(locale.getDisplayCountry());
        Locationbox.setText(String.valueOf(Zone));
        resourceBundle = ResourceBundle.getBundle("languages/login", locale);
        UsernameLabel.setText(resourceBundle.getString("username"));
        PasswordLabel.setText(resourceBundle.getString("password"));
        LoginButton.setText(resourceBundle.getString("login"));
        ExitButton.setText(resourceBundle.getString("exit"));
        errorTitle = resourceBundle.getString("errortitle");
        errorHeader = resourceBundle.getString("errorheader");
        errorText = resourceBundle.getString("errortext");
        loginLabel.setText(resourceBundle.getString("loginlabel"));
    }
}

